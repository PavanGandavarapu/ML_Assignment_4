#!/usr/bin/env python
# coding: utf-8

# In[72]:


#Q1 Read the provided CSV file ‘data.csv’.
import pandas as pd
df = pd.read_csv('C:/Users/gowth/Desktop/UCM/ML/Assignment 4/data.csv')


# In[73]:


#Q2 Show the basic statistical description about the data.

DataDescription = df.describe()
print(DataDescription)


# In[74]:


#Q3 Check if the data has null values and Replace the null values with the mean

# Check for null values
null_rows = df[df.isnull().any(axis=1)]
print(null_rows)

# Replace null values in the Calories column with the mean value
df['Calories'].fillna(df['Calories'].mean(), inplace=True)

# Check for null values again
null_rows = df[df.isnull().any(axis=1)]
print(null_rows)


# In[65]:


#Q4 Select at least two columns and aggregate the data using: min, max, count, mean.

# Select two columns and aggregate the data
agg_df = df[['Duration', 'Calories']].agg(['min', 'max', 'count', 'mean'])

# Display the aggregated data
print(agg_df)


# In[75]:


#Q5 Filter the dataframe to select the rows with calories values between 500 and 1000.

# Filter the DataFrame to select rows with Calories values between 500 and 1000
filtered_df = df[(df['Calories'] >= 500) & (df['Calories'] <= 1000)]

# Display the filtered DataFrame
print(filtered_df)


# In[67]:


#Q6 Filter the dataframe to select the rows with calories values > 500 and pulse < 100

# Filter the DataFrame to select rows with Calories values > 500 and Pulse values < 100
filtered_df = df[(df['Calories'] > 500) & (df['Pulse'] < 100)]

# Display the filtered DataFrame
print(filtered_df)


# In[68]:


#Q7 Create a new “df_modified” dataframe that contains all the columns from df except for “Maxpulse”

# Create a new DataFrame with all columns except Maxpulse
df_modified = df.drop('Maxpulse', axis=1)

# Display the modified DataFrame
print(df_modified)


# In[76]:


#Q8 Delete the “Maxpulse” column from the main df dataframe

# Delete the Maxpulse column from the main DataFrame
df.drop('Maxpulse', axis=1, inplace=True)

# Display the modified DataFrame
print(df)


# In[77]:


#Q9 Convert the datatype of Calories column to int datatype.

# Convert the data type of the Calories column from float to int
df['Calories'] = df['Calories'].astype(int)

# Display the modified DataFrame
print(df)


# In[71]:


#Q10 Using pandas create a scatter plot for the two columns (Duration and Calories).

import pandas as pd
import matplotlib.pyplot as plt

# Load the CSV file
df = pd.read_csv('C:/Users/gowth/Desktop/UCM/ML/Assignment 4/data.csv')

# Create a scatter plot of the Duration and Calories columns
df.plot(kind='scatter', x='Duration', y='Calories')

# Show the plot
plt.show()


# In[ ]:




