#!/usr/bin/env python
# coding: utf-8

# In[16]:


#Q1 Implement Naïve Bayes method using scikit-learn library
    # a. Use the glass dataset available in Link also provided in your assignment.
    # b. Use train_test_split to create training and testing part.
#Evaluate the model on testing part using score and classification_report(y_true, y_pred)

import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import GaussianNB
from sklearn.metrics import classification_report

# Load the dataset
file_path = "C:/Users/gowth/Desktop/UCM/ML/Assignment 4/Dataset/glass.csv"
df = pd.read_csv(file_path)

# Split the dataset into training and testing parts
X = df.drop("Type", axis=1)
y = df["Type"]
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

# Train the Naïve Bayes model
model = GaussianNB()
model.fit(X_train, y_train)

# Evaluate the model
score = model.score(X_test, y_test)
y_pred = model.predict(X_test)
report = classification_report(y_test, y_pred)

print("Accuracy:", score)
print("\nClassification Report:\n", report)


# In[17]:


#Q2 Implement linear SVM method using scikit library
    # a. Use the glass dataset available in Link also provided in your assignment.
    # b. Use train_test_split to create training and testing part.
#Evaluate the model on testing part using score and classification_report(y_true, y_pred)
    
import warnings
from sklearn.exceptions import UndefinedMetricWarning
warnings.filterwarnings("ignore", category=UndefinedMetricWarning)

import warnings
from sklearn.exceptions import UndefinedMetricWarning
warnings.filterwarnings("ignore", category=UndefinedMetricWarning)

import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.svm import SVC
from sklearn.metrics import classification_report

# Load the dataset
file_path = "C:/Users/gowth/Desktop/UCM/ML/Assignment 4/Dataset/glass.csv"
df = pd.read_csv(file_path)

# Split the dataset into training and testing parts
X = df.drop("Type", axis=1)
y = df["Type"]
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

# Train the linear SVM model
model = SVC(kernel="linear", C=1)
model.fit(X_train, y_train)

# Evaluate the model
score = model.score(X_test, y_test)
y_pred = model.predict(X_test)
report = classification_report(y_test, y_pred)

print("Accuracy:", score)
print("\nClassification Report:\n", report)


# In[15]:


#Q3 Do at least two visualizations to describe or show correlations in the Glass Dataset. 

import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

# Load the dataset
file_path = "C:/Users/gowth/Desktop/UCM/ML/Assignment 4/Dataset/glass.csv"
df = pd.read_csv(file_path)

# Bar plot of glass type distribution
plt.figure(figsize=(8, 6))
sns.countplot(x="Type", data=df, palette="bright")
plt.title("Glass Type Distribution")
plt.xlabel("Glass Type")
plt.ylabel("Frequency")
plt.show()

# Scatter plot matrix of selected features
selected_features = ["RI", "Na", "Mg", "Al", "Si", "Type"]
sns.pairplot(df[selected_features], hue="Type", palette="bright", markers=".", diag_kind="hist")
plt.title("Scatter Plot Matrix of Selected Features")
plt.show()


# In[ ]:




